# NOVA TECH – Thực hành Tuần 5 (ExpressJS / EJS / MongoDB)

Mã nguồn kèm bài Word Tuần 5. Không chứa mật khẩu.

## Chạy
1. `cd backend`
2. Copy `.env.example` thành `.env` rồi cập nhật `MONGO_URI`, `SESSION_SECRET` riêng; tên DB gợi ý `shop_tuan5_tuan6`.
3. `npm install`
4. `npm run seed` (lần đầu, nhập 15 mẫu)
5. `npm start`
6. Mở `http://localhost:3000/products`

Test CRUD: `postman/Tuan5_CRUD_Cart.postman_collection.json`; endpoint `http://localhost:3000/api/products`.

## Nộp bài
Theo đề, file Word cần link repository GitHub thật. Giải nén rồi đưa các file source lên GitHub, KHÔNG đẩy `backend/.env`/`node_modules`.
