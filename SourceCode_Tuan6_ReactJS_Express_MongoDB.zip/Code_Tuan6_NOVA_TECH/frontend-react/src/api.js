export const money = (n) => new Intl.NumberFormat('vi-VN').format(n || 0) + ' ₫';
export async function api(path, options = {}) {
  const response = await fetch('/api' + path, {
    credentials: 'include',
    headers: { 'Content-Type': 'application/json', ...(options.headers || {}) },
    ...options
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.message || `Lỗi HTTP ${response.status}`);
  return data;
}
