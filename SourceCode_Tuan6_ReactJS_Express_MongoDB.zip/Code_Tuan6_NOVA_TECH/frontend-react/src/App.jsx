import React, { createContext, useCallback, useContext, useEffect, useState } from 'react';
import { Link, NavLink, Navigate, Route, Routes, useNavigate, useParams } from 'react-router-dom';
import { api, money } from './api';

const CartContext = createContext(null);
const useCart = () => useContext(CartContext);

function App() {
  const [cart, setCart] = useState({ items: [], count: 0, total: 0 });
  const [error, setError] = useState('');
  const refreshCart = useCallback(async () => {
    try { setCart(await api('/cart')); }
    catch (e) { setError(e.message); }
  }, []);
  useEffect(() => { refreshCart(); }, [refreshCart]);
  const add = async (productId, quantity = 1) => {
    await api('/cart/items', { method: 'POST', body: JSON.stringify({ productId, quantity }) });
    await refreshCart();
  };
  const update = async (id, quantity) => {
    await api('/cart/items/' + id, { method: 'PATCH', body: JSON.stringify({ quantity }) });
    await refreshCart();
  };
  const remove = async (id) => { await api('/cart/items/' + id, { method: 'DELETE' }); await refreshCart(); };
  const clear = async () => { await api('/cart', { method: 'DELETE' }); await refreshCart(); };
  return <CartContext.Provider value={{cart, add, update, remove, clear}}>
    <div className="utility-bar">BÀI THỰC HÀNH TUẦN 6 • REACTJS + EXPRESS API + MONGODB</div>
    <header className="site-header"><div className="container nav-layout">
      <Link to="/products" className="brand"><span className="brand-mark">N</span><span>NOVA<span className="brand-accent">TECH</span><small>TECH FOR EVERY DAY</small></span></Link>
      <nav className="nav"><NavLink to="/products" className="nav-link">Sản phẩm</NavLink><NavLink to="/cart" className="nav-cart">🛍 Giỏ hàng <span className="count">{cart.count}</span></NavLink></nav>
    </div></header>
    {error && <div className="container notice" role="alert">{error}</div>}
    <main><Routes><Route path="/" element={<Navigate replace to="/products" />} /><Route path="/products" element={<Products />} /><Route path="/products/:id" element={<ProductDetails />} /><Route path="/cart" element={<Cart />} /><Route path="*" element={<NotFound />} /></Routes></main>
    <footer className="site-footer"><div className="container footer-layout"><strong>NOVA TECH</strong><span>Đồ án thực hành • ReactJS + Express API</span><Link to="/products">Về cửa hàng ↑</Link></div></footer>
  </CartContext.Provider>;
}

function categoryIcon(category) { return ({'Laptop':'💻','Điện thoại':'📱','Âm thanh':'🎧','Đồng hồ':'⌚','Máy tính bảng':'▣','Phụ kiện':'🔌'})[category] || '✦'; }
function ProductPhoto({ product, className }) {
  return <div className={className}><span className="image-fallback">{categoryIcon(product.category)}</span>{product.image && <img src={product.image} alt={product.name} onError={(e)=>{e.currentTarget.style.display='none';}} />}</div>;
}
function Products() {
  const [products, setProducts] = useState([]);
  const [query, setQuery] = useState('');
  const [category, setCategory] = useState('Tất cả');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [message, setMessage] = useState('');
  const {add} = useCart();
  useEffect(() => { api('/products?visible=1').then(setProducts).catch(e => setError(e.message)).finally(()=>setLoading(false)); }, []);
  const cats = ['Tất cả', ...new Set(products.map(p=>p.category))];
  const filtered = products.filter(p => (category === 'Tất cả' || p.category === category) && p.name.toLowerCase().includes(query.trim().toLowerCase()));
  const handleAdd = async p => {
    try { await add(p._id); setMessage('Đã thêm ' + p.name + ' vào giỏ hàng.'); }
    catch(e) { setError(e.message); }
  };
  return <>
    <section className="hero"><div className="container hero-inner"><div><span className="eyebrow">NEW COLLECTION / 2026</span><h1>Công nghệ chất.<br/><span>Cuộc sống khác biệt.</span></h1><p>Một cửa hàng công nghệ với trải nghiệm React hiện đại, kết nối API Express và MongoDB.</p><a href="#catalog" className="button button-light">Khám phá sản phẩm →</a></div><div className="hero-art" aria-hidden="true"><span>✦</span><div className="glass-phone"><div /></div><i>FUTURE<br/>IS NOW</i></div></div></section>
    <section className="container catalog-section" id="catalog"><div className="section-heading"><div><span className="eyebrow dark">EXPLORE COLLECTION</span><h2>Danh sách sản phẩm</h2><p>Chọn danh mục hoặc tìm kiếm sản phẩm yêu thích.</p></div><span className="result-count">{filtered.length} sản phẩm</span></div>
      <div className="filter-row"><div className="cat-list">{cats.map(c => <button key={c} className={'cat-pill ' + (category===c?'active':'')} onClick={()=>setCategory(c)}>{c}</button>)}</div><input className="search-input" placeholder="⌕  Tìm sản phẩm..." value={query} onChange={e=>setQuery(e.target.value)} /></div>
      {message && <div className="notice success" role="status">✓ {message}</div>}{error && <div className="notice" role="alert">{error}</div>}
      {loading ? <div className="empty">Đang tải sản phẩm...</div> : <div className="product-grid">{filtered.map(p => <article className="product-card" key={p._id}>
        <Link to={'/products/'+p._id} aria-label={'Xem '+p.name}><ProductPhoto className="image-holder" product={p}/></Link><div className="product-meta"><span className="product-category">{p.category}</span><h3>{p.name}</h3><p>{p.description}</p><div className="price-line"><strong>{money(p.price)}</strong><small>{p.stock ? 'Còn ' + p.stock : 'Hết hàng'}</small></div><div className="card-actions"><Link className="button button-outline" to={'/products/'+p._id}>Chi tiết ↗</Link><button className="button button-dark" onClick={()=>handleAdd(p)} disabled={!p.stock}>+ Giỏ hàng</button></div></div></article>)}</div>}
      {!loading && !filtered.length && <div className="empty">Không tìm thấy sản phẩm phù hợp.</div>}
    </section>
  </>;
}
function ProductDetails() {
  const {id} = useParams();
  const nav = useNavigate();
  const [product,setProduct] = useState(null);
  const [quantity,setQuantity] = useState(1);
  const [error,setError] = useState('');
  const {add} = useCart();
  useEffect(()=>{setProduct(null);api('/products/'+id).then(setProduct).catch(e=>setError(e.message));},[id]);
  const handleAdd=async e=>{e.preventDefault();try{await add(id,Number(quantity));nav('/cart');}catch(e){setError(e.message);}};
  if(error && !product) return <div className="container empty">{error} <Link to="/products">Quay lại</Link></div>;
  if(!product) return <div className="container empty">Đang tải chi tiết...</div>;
  return <section className="container detail-page"><Link className="breadcrumb" to="/products">← Cửa hàng / {product.category}</Link><div className="detail-grid"><ProductPhoto className="detail-photo" product={product}/><div className="detail-content"><span className="eyebrow dark">PRODUCT DETAILS / {product.category.toUpperCase()}</span><h1>{product.name}</h1><div className="detail-divider"/><p className="detail-price">{money(product.price)}</p><p className="detail-description">{product.description}</p><div className="detail-stock"><span className="dot"/> {product.stock ? 'Còn ' + product.stock + ' sản phẩm' : 'Hết hàng'}</div>{error && <div className="notice">{error}</div>}<form className="detail-form" onSubmit={handleAdd}><label>Số lượng <input className="qty-input" type="number" min="1" max={product.stock} value={quantity} onChange={e=>setQuantity(e.target.value)} required /></label><button className="button button-dark button-wide" disabled={!product.stock}>+ Thêm vào giỏ hàng</button></form><Link className="small-link" to="/cart">Xem giỏ hàng →</Link><div className="service-box">✓ Dữ liệu lấy từ Express REST API<br/>✓ Quản lý giỏ hàng qua Session</div></div></div></section>;
}
function Cart() {
  const {cart,update,remove,clear} = useCart();
  const [quantities,setQuantities] = useState({});
  const [error,setError] = useState('');
  useEffect(()=>{const next={};cart.items.forEach(it=>next[it.product._id]=it.quantity);setQuantities(next);},[cart]);
  const doIt=async(fn)=>{try{setError('');await fn();}catch(e){setError(e.message);}};
  return <section className="container cart-page"><Link className="breadcrumb" to="/products">← Tiếp tục mua hàng</Link><div className="section-heading"><div><span className="eyebrow dark">YOUR SHOPPING BAG</span><h1>Giỏ hàng của bạn</h1><p>{cart.count} sản phẩm trong giỏ</p></div></div>{error && <div className="notice">{error}</div>}
    {cart.items.length ? <div className="cart-layout"><div className="cart-items">{cart.items.map(item=><article className="cart-item" key={item.product._id}><Link to={'/products/'+item.product._id}><ProductPhoto className="cart-thumb" product={item.product}/></Link><div className="cart-info"><span className="eyebrow dark">{item.product.category}</span><Link className="cart-name" to={'/products/'+item.product._id}>{item.product.name}</Link><strong>{money(item.product.price)}</strong><div className="cart-controls"><label>SL <input type="number" min="0" max={item.product.stock} value={quantities[item.product._id]??item.quantity} onChange={e=>setQuantities({...quantities,[item.product._id]:e.target.value})}/></label><button className="text-button" onClick={()=>doIt(()=>update(item.product._id,Number(quantities[item.product._id])))}>Cập nhật</button><button className="text-button danger" onClick={()=>doIt(()=>remove(item.product._id))}>Xóa</button></div></div><strong className="subtotal">{money(item.subtotal)}</strong></article>)}</div><aside className="summary"><h2>Thông tin đơn hàng</h2><div className="summary-line"><span>Số lượng</span><strong>{cart.count}</strong></div><div className="summary-line"><span>Tạm tính</span><strong>{money(cart.total)}</strong></div><div className="summary-line total"><span>Tổng cộng</span><strong>{money(cart.total)}</strong></div><p>Website thực hành, chưa tích hợp thanh toán.</p><Link to="/products" className="button button-dark button-wide">Mua thêm sản phẩm →</Link><button className="clear-button" onClick={()=>doIt(clear)}>Xóa toàn bộ giỏ hàng</button></aside></div> : <div className="empty-cart"><span>🛍</span><h2>Giỏ hàng đang trống</h2><p>Hãy chọn món đồ công nghệ bạn yêu thích!</p><Link className="button button-dark" to="/products">Khám phá sản phẩm →</Link></div>}</section>;
}
function NotFound(){return <div className="container empty-cart"><h1>404</h1><Link className="button button-dark" to="/products">Về cửa hàng</Link></div>}
export default App;
