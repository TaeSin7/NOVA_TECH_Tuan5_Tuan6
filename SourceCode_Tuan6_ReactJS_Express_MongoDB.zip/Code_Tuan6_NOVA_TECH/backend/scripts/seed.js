require('dotenv').config();
const mongoose = require('mongoose');
const path = require('path');
const Product = require('../src/models/Product');
const products = require(path.join(__dirname, '../data/seed-products.json'));

(async function seed() {
  await mongoose.connect(process.env.MONGO_URI || 'mongodb://127.0.0.1:27017/shop_tuan5_tuan6');
  let inserted = 0;
  for (const product of products) {
    const found = await Product.exists({ name: product.name });
    if (!found) { await Product.create(product); inserted++; }
  }
  console.log(`Seed hoàn tất: thêm ${inserted} / ${products.length} sản phẩm (không tạo dữ liệu trùng).`);
  await mongoose.disconnect();
})().catch(err => { console.error(err.message); process.exit(1); });
