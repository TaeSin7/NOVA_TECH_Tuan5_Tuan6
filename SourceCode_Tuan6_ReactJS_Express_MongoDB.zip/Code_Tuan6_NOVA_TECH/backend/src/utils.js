const mongoose = require('mongoose');
const Product = require('./models/Product');

const asyncHandler = (fn) => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);
const money = (value) => new Intl.NumberFormat('vi-VN').format(value || 0) + ' ₫';

function validateProduct(data) {
  const errors = [];
  const name = String(data.name || '').trim();
  const category = String(data.category || '').trim();
  const price = Number(data.price);
  const stock = Number(data.stock);
  if (!name) errors.push('Tên sản phẩm không được trống.');
  if (!category) errors.push('Danh mục không được trống.');
  if (data.price === '' || data.price === undefined || !Number.isFinite(price) || price < 0) errors.push('Giá không hợp lệ.');
  if (data.stock === '' || data.stock === undefined || !Number.isInteger(stock) || stock < 0) errors.push('Số lượng tồn kho phải là số nguyên không âm.');
  return {
    errors,
    product: {
      name, category, price, stock,
      description: String(data.description || '').trim(),
      image: String(data.image || '').trim(),
      show: data.show === undefined ? true : (data.show === true || data.show === 'true')
    }
  };
}

function validId(id) { return mongoose.isValidObjectId(id); }

async function cartSummary(session) {
  const cart = session.cart || {};
  const ids = Object.keys(cart).filter(validId);
  if (!ids.length) return { items: [], count: 0, total: 0 };
  const products = await Product.find({ _id: { $in: ids } }).lean();
  const items = products.map(product => {
    const quantity = Number(cart[String(product._id)]) || 0;
    return { product, quantity, subtotal: product.price * quantity };
  }).filter(item => item.quantity > 0);
  // Remove deleted products from session.
  const existing = new Set(items.map(x => String(x.product._id)));
  for (const id of ids) if (!existing.has(id)) delete session.cart[id];
  return {
    items,
    count: items.reduce((sum, item) => sum + item.quantity, 0),
    total: items.reduce((sum, item) => sum + item.subtotal, 0)
  };
}

async function changeCart(req, id, quantity, replace = false) {
  if (!validId(id)) { const e = new Error('ID sản phẩm không hợp lệ.'); e.status = 400; throw e; }
  const product = await Product.findById(id).lean();
  if (!product || !product.show) { const e = new Error('Không tìm thấy sản phẩm.'); e.status = 404; throw e; }
  const qty = Number(quantity);
  if (!Number.isInteger(qty) || qty < 0) { const e = new Error('Số lượng phải là số nguyên không âm.'); e.status = 400; throw e; }
  if (!req.session.cart) req.session.cart = {};
  const existing = Number(req.session.cart[id]) || 0;
  const target = replace ? qty : existing + qty;
  if (target > product.stock) { const e = new Error('Số lượng vượt quá tồn kho.'); e.status = 400; throw e; }
  if (target === 0) delete req.session.cart[id];
  else req.session.cart[id] = target;
}

module.exports = { asyncHandler, money, validateProduct, validId, cartSummary, changeCart };
