const express = require('express');
const Product = require('../models/Product');
const { asyncHandler, validateProduct, validId, cartSummary, changeCart } = require('../utils');
const router = express.Router();

router.get('/products', asyncHandler(async (req, res) => {
  const filter = req.query.visible === '1' ? { show: true } : {};
  if (req.query.category) filter.category = req.query.category;
  if (req.query.q) filter.name = { $regex: String(req.query.q).replace(/[.*+?^${}()|[\]\\]/g,'\\$&'), $options: 'i' };
  res.json(await Product.find(filter).sort({ createdAt: -1 }).lean());
}));

router.get('/products/:id', asyncHandler(async (req, res) => {
  if (!validId(req.params.id)) return res.status(400).json({ message: 'ID không hợp lệ.' });
  const product = await Product.findById(req.params.id).lean();
  if (!product) return res.status(404).json({ message: 'Không tìm thấy sản phẩm.' });
  res.json(product);
}));

router.post('/products', asyncHandler(async (req, res) => {
  const { errors, product } = validateProduct(req.body);
  if (errors.length) return res.status(400).json({ message: errors.join(' ') });
  const created = await Product.create(product);
  res.status(201).json(created);
}));

router.put('/products/:id', asyncHandler(async (req, res) => {
  if (!validId(req.params.id)) return res.status(400).json({ message: 'ID không hợp lệ.' });
  const { errors, product } = validateProduct(req.body);
  if (errors.length) return res.status(400).json({ message: errors.join(' ') });
  const updated = await Product.findByIdAndUpdate(req.params.id, product, { new: true, runValidators: true });
  if (!updated) return res.status(404).json({ message: 'Không tìm thấy sản phẩm.' });
  res.json(updated);
}));

router.delete('/products/:id', asyncHandler(async (req, res) => {
  if (!validId(req.params.id)) return res.status(400).json({ message: 'ID không hợp lệ.' });
  const deleted = await Product.findByIdAndDelete(req.params.id);
  if (!deleted) return res.status(404).json({ message: 'Không tìm thấy sản phẩm.' });
  res.json({ message: 'Xóa sản phẩm thành công.', id: req.params.id });
}));

router.get('/cart', asyncHandler(async (req, res) => res.json(await cartSummary(req.session))));
router.post('/cart/items', asyncHandler(async (req, res) => {
  await changeCart(req, req.body.productId, req.body.quantity || 1);
  res.status(201).json(await cartSummary(req.session));
}));
router.patch('/cart/items/:id', asyncHandler(async (req, res) => {
  await changeCart(req, req.params.id, req.body.quantity, true);
  res.json(await cartSummary(req.session));
}));
router.delete('/cart/items/:id', asyncHandler(async (req, res) => {
  if (!req.session.cart) req.session.cart = {};
  delete req.session.cart[req.params.id];
  res.json(await cartSummary(req.session));
}));
router.delete('/cart', asyncHandler(async (req, res) => {
  req.session.cart = {};
  res.json({ items: [], count: 0, total: 0 });
}));

module.exports = router;
