const express = require('express');
const Product = require('../models/Product');
const { asyncHandler, money, validId, cartSummary, changeCart } = require('../utils');
const router = express.Router();

router.get('/', (req, res) => res.redirect('/products'));
router.get('/products', asyncHandler(async (req, res) => {
  const [products, cart] = await Promise.all([
    Product.find({ show: true }).sort({ createdAt: -1 }).lean(),
    cartSummary(req.session)
  ]);
  res.render('products', { title: 'Sản phẩm', products, cart, money, flash: req.query.message || '' });
}));
router.get('/products/:id', asyncHandler(async (req, res) => {
  if (!validId(req.params.id)) return res.status(404).render('notfound', { title: 'Không tìm thấy', cart: await cartSummary(req.session) });
  const [product, cart] = await Promise.all([ Product.findById(req.params.id).lean(), cartSummary(req.session) ]);
  if (!product || !product.show) return res.status(404).render('notfound', { title: 'Không tìm thấy', cart });
  res.render('detail', { title: product.name, product, cart, money });
}));
router.get('/cart', asyncHandler(async (req, res) => {
  res.render('cart', { title: 'Giỏ hàng', cart: await cartSummary(req.session), money, flash: req.query.message || '' });
}));
router.post('/cart/add', asyncHandler(async (req, res) => {
  await changeCart(req, req.body.productId, req.body.quantity || 1);
  res.redirect('/cart');
}));
router.post('/cart/update', asyncHandler(async (req, res) => {
  await changeCart(req, req.body.productId, req.body.quantity, true);
  res.redirect('/cart');
}));
router.post('/cart/remove', asyncHandler(async (req, res) => {
  if (!req.session.cart) req.session.cart = {};
  delete req.session.cart[req.body.productId];
  res.redirect('/cart');
}));
router.post('/cart/clear', (req, res) => {
  req.session.cart = {};
  res.redirect('/cart');
});
module.exports = router;
