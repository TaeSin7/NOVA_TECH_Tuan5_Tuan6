require('dotenv').config();
const path = require('path');
const express = require('express');
const mongoose = require('mongoose');
const session = require('express-session');
const apiRouter = require('./routes/api');
const pageRouter = require('./routes/pages');

const app = express();
app.disable('x-powered-by');
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));
app.use(session({
  secret: process.env.SESSION_SECRET || 'local-dev-only-change-this-secret',
  resave: false,
  saveUninitialized: false,
  cookie: { httpOnly: true, sameSite: 'lax', maxAge: 24 * 60 * 60 * 1000 }
}));
app.use('/api', apiRouter);
app.use('/', pageRouter);
app.use((req, res) => {
  if (req.path.startsWith('/api')) return res.status(404).json({ message: 'Không tìm thấy API.' });
  res.status(404).send('404 - Không tìm thấy trang.');
});
app.use((error, req, res, _next) => {
  console.error('[ERROR]', error.message);
  const status = error.status || (error.name === 'ValidationError' ? 400 : 500);
  if (req.path.startsWith('/api')) return res.status(status).json({ message: status === 500 ? 'Lỗi máy chủ.' : error.message });
  res.status(status).send(`<h2>${status} - Yêu cầu không thực hiện được</h2><p>${status === 500 ? 'Lỗi máy chủ.' : 'Dữ liệu chưa hợp lệ.'}</p><a href="/products">Quay lại cửa hàng</a>`);
});

const mongoUri = process.env.MONGO_URI || 'mongodb://127.0.0.1:27017/shop_tuan5_tuan6';
const port = Number(process.env.PORT) || 3000;
mongoose.connect(mongoUri).then(() => {
  app.listen(port, () => console.log(`EJS + REST API: http://localhost:${port}/products`));
  console.log('MongoDB connected.');
}).catch(err => {
  console.error('Không kết nối được MongoDB:', err.message);
  process.exitCode = 1;
});
