# NOVA TECH – Thực hành Tuần 6 (React / Express API / MongoDB)

Bài Tuần 6 cần cả Frontend React lẫn Backend từ Tuần 5; ZIP này chứa đủ hai phần.

## Chạy
1. Terminal 1: `cd backend` → copy `.env.example` thành `.env` và cấu hình MongoDB Atlas + SESSION_SECRET cục bộ → `npm install` → `npm run seed` (lần đầu) → `npm start` (cổng 3000).
2. Terminal 2: `cd frontend-react` → `npm install` → `npm run dev` (cổng 5173).
3. Mở `http://localhost:5173/products`; vào chi tiết, thêm/sửa/xóa giỏ hàng.

Frontend gọi backend bằng Vite proxy `/api`. Nếu backend đã chạy, không chạy thêm phiên backend thứ hai.

## Nộp bài
Theo đề, file Word cần link repository GitHub thật. Giải nén rồi đưa source lên GitHub; KHÔNG đẩy `backend/.env`, `node_modules`.
